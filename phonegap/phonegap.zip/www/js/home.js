/**
 * Created by Freezyy on 6/7/2015.
 */
//if(isLogged) {
//    $(".logout").css({display: "inline-block"})
//}
//else
//{
//    $(".logout").css({display: "none"})
//}
